# RUBEZH — Render + Printful starter

Render settings:
- Build Command: npm install
- Start Command: npm start
- Plan: Free
- Environment variable: PRINTFUL_TOKEN = your Printful Private Token

Endpoints: /, /api/health, /api/printful/store, /api/printful/products

Never put the Printful token in frontend JavaScript or GitHub.
