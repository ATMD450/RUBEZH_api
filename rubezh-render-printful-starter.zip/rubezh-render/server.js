const express = require('express');
const app = express();
app.use(express.json());
const PORT = process.env.PORT || 10000;
const TOKEN = process.env.PRINTFUL_TOKEN;
app.get('/', (_req,res)=>res.json({app:'RUBEZH API',status:'online',printfulConfigured:Boolean(TOKEN)}));
app.get('/api/health', (_req,res)=>res.json({ok:true,service:'rubezh-api'}));
app.get('/api/printful/store', async (_req,res)=>{
  if(!TOKEN) return res.status(503).json({ok:false,error:'PRINTFUL_TOKEN is not configured'});
  try { const r=await fetch('https://api.printful.com/store',{headers:{Authorization:`Bearer ${TOKEN}`,Accept:'application/json'}}); res.status(r.status).json(await r.json()); }
  catch(e){res.status(500).json({ok:false,error:'Could not connect to Printful',details:e.message});}
});
app.get('/api/printful/products', async (_req,res)=>{
  if(!TOKEN) return res.status(503).json({ok:false,error:'PRINTFUL_TOKEN is not configured'});
  try { const r=await fetch('https://api.printful.com/sync/products',{headers:{Authorization:`Bearer ${TOKEN}`,Accept:'application/json'}}); res.status(r.status).json(await r.json()); }
  catch(e){res.status(500).json({ok:false,error:'Could not load Printful products',details:e.message});}
});
app.listen(PORT,'0.0.0.0',()=>console.log(`RUBEZH API listening on ${PORT}`));
